import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router'

import { AuthService } from './authService'
import { Auth } from './auth';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  auth: Auth;
  // prod: Produit;

  authForm: FormGroup;


  selectedAuth: Auth;


  constructor(private authService: AuthService, private fb: FormBuilder, private route: ActivatedRoute) {
  this.createForm();
   }

  ngOnInit() {
    // this.initProduit();
    // console.log(this.prod);
    // this.produits = this.produitService.getProduits();
    this.initAuth();
    //this.loadProduits(); On remplace par la ligne suivante (un resolve soit une promesse) soit on a le get soit une réponse précise
    this.auth = this.route.snapshot.data.produits;
  }

  createForm() {
    this.authForm = this.fb.group({
      mail: '',
      password: ''
    })
    console.log("createForm")
  }

  // initProduit(){
  //   this.prod = new Produit();
  //   this.prod.ref = 'aa';
  // }

  //j'instancie un selectProduit de type Produit; dans mon formulaire en front je prend les valeur avec les ngModel
  initAuth(){
    this.selectedAuth = new Auth();
    console.log("init auth")
    this.createForm();
  }


  login() {
    console.log("je suis login")
    const p = this.selectedAuth;
    console.log(p)
    this.authService.login(p.mail, p.password).subscribe(
      res => {
        console.log("ici res ");
        console.log(res);
        this.initAuth()
      }
    );
  }

}

