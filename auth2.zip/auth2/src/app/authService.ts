import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Auth } from './auth';

@Injectable()
export class AuthService{

    constructor(private http:HttpClient){

    }

    
    //Observable<any> prend tout les types de valeur
    //Observable<String> ne get que les Strings
    getProduits(): Observable<any>{
        return this.http.get("http://localhost:8181/user");
    }

    addProduit(auth: Auth): Observable<any>{
        return this.http.post("http://localhost:8181/user", auth);
    }

    updateProduit(auth: Auth): Observable<any>{
        return this.http.put("http://localhost:8181/user", auth);
    }

    deleteProduit(id: number): Observable<any>{
        return this.http.delete("http://localhost:8181/user"+ `${id}`);
    }//`${this.heroesUrl}/${id}`
    //API_URLS.PRODUITS_URL+ `/${ref}`
    //`${API_URLS.PRODUITS_URL}/${ref}`


    login(mail: String, password: String): Observable<any>{
        console.log("je suis service")
        console.log(mail);
        console.log(password);
        return this.http.post("http://localhost:8181/ano/login", {mail, password});
    }
}