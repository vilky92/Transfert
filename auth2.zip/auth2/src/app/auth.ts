export class Auth{
    constructor(
                public mail?: string,
                public password?: string,
                ) {

    }
}