package angular.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JwtCredential {

	private String jwt;

	public JwtCredential(String jwt) {
		super();
		this.jwt = jwt;
	}
	
	
}
