package angular.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import angular.dto.JwtCredential;
import angular.model.Role;
import angular.model.User;
import angular.repository.RoleRepository;
import angular.repository.UserRepository;
import angular.security.JWTService;



@CrossOrigin(value="*")
@RestController
@RequestMapping("/ano")
public class AnoController {
	
	@Autowired
	private JWTService jwtService;
	
	@Autowired
	private PasswordEncoder encoder;
		
	
	@Autowired
	private UserRepository usersR;
	
	
	@PostMapping("/post")
	public ResponseEntity<?> createUser(@RequestBody User user) {

		User john = new User();;
		john.setMail(user.getMail());
		john.setPassword(encoder.encode(user.getPassword()));

		usersR.save(john);

		return new ResponseEntity<User>(john,HttpStatus.OK);
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> connexion(@RequestBody User user, HttpServletRequest request) throws Exception {
				System.out.println(user.getMail());
				System.out.println(user.getPassword());
		if (!usersR.existsByMail(user.getMail())) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Bad user");
		}

		User josh = usersR.findByMail(user.getMail());

		if (!josh.isActif()) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Disabled");
		}

		if (!encoder.matches(user.getPassword(), josh.getPassword())) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Bad password");
		}
	
		List<String> roles = new ArrayList<String>();
		for (Role role : josh.getRoles()) {
			roles.add(role.getLabel());
		}

		String jwt = jwtService.createJWT(josh.getMail(), roles);
		JwtCredential response = new JwtCredential(jwt);
		
		return ResponseEntity.ok().body(response);

	}
	
	
	
}

