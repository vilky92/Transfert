package angular.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	private String mail;
	
	private String password;
	
	private boolean actif = true;
	
	@ManyToMany
	@JoinTable(name="Role_Users")
	private Set<Role> roles = new HashSet<Role>();

	public User(String mail, String password) {
		super();
		this.mail = mail;
		this.password = password;
	}

	public User() {
		super();
	}
	

}
