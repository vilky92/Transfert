package angular.data;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import angular.model.Role;
import angular.model.User;
import angular.repository.RoleRepository;
import angular.repository.UserRepository;

@Component
public class InitData implements CommandLineRunner{

	@Autowired
	private UserRepository users;
	
	@Autowired
	private RoleRepository roles;
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Override
	public void run(String... args) throws Exception {
		
		if (roles.count() == 0) {
			Role user = new Role ("user");
			Role admin = new Role ("admin");
			
			roles.saveAll(Arrays.asList(user, admin));
		}
		
		if ( users.count() == 0) {
			User user = new User ("user@user", encoder.encode("user"));
			User admin = new User ("admin@admin", encoder.encode("admin"));
			
			Role userRole = roles.findByLabel("user");
			Role adminRole = roles.findByLabel("admin");
			
			Set<Role> adminR = new HashSet<Role>();
			Set<Role> userR = new HashSet<Role>();
			userR.add(userRole);
			adminR.add(adminRole);
			user.setRoles(userR);
			admin.setRoles(adminR);
			users.saveAll(Arrays.asList(user,admin));
		}
	}

}
