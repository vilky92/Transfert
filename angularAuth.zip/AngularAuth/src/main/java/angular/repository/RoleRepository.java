package angular.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import angular.model.Role;

public interface RoleRepository extends JpaRepository<Role, Long>{

	Role findByLabel(String string);
}
