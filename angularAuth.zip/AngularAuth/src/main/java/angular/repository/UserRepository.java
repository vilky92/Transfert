package angular.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import angular.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

	boolean existsByMail(String mail);

	User findByMail(String mail);
}
