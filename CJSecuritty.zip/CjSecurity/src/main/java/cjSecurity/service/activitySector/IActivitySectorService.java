package cjSecurity.service.activitySector;

public interface IActivitySectorService {

}
