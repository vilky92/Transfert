package cjSecurity.service.activitySector;

public class ActivitySector {

}
