package cjSecurity.service.application;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cjSecurity.dto.ApplicationDTO;
import cjSecurity.dto.UserApplicationDTO;
import cjSecurity.model.activitySector.ActivitySector;
import cjSecurity.model.application.Application;
import cjSecurity.model.user.User;
import cjSecurity.repository.activitySector.IActivitySectorRepository;
import cjSecurity.repository.application.IApplicationRepository;
import cjSecurity.repository.user.IUserRepository;

@Service
public class ApplicationService implements IApplicationService {

	@Autowired
	private IActivitySectorRepository activitySector;

	@Autowired
	private IApplicationRepository applications;

	@Autowired
	private IUserRepository users;

	@Override
	public Application createApplication(UserApplicationDTO applicationDTO) {
		User john = users.findById(applicationDTO.getUserId()).get();

		Application apply = new Application();
		
		ActivitySector  activity = null;
		activity = activitySector.findByLabel(applicationDTO.getSectorLabel());		
		
		apply.setActivitySector(activity);
		apply.setAddress(applicationDTO.getAddress());
		apply.setCity(applicationDTO.getCity());
		apply.setCoverLetter(applicationDTO.getCoverLetter());
		apply.setNumberCard(applicationDTO.getNumberCard());
		apply.setNumberPhone(applicationDTO.getNumberPhone());
		apply.setUser(john);		

		john.setApplication(apply);

		return applications.save(apply);
	}

	@Override
	public Application updateApplication(UserApplicationDTO application) {
		Application result = null;
		User john = users.findById(application.getUserId()).get();
		Application apply = john.getApplication();

		apply.setActivitySector(activitySector.findByLabel(application.getSectorLabel()));

		if (application.getAddress() != null) {
			apply.setAddress(application.getAddress());
		}
		if (application.getCity() != null) {
			apply.setCity(application.getCity());
		}
		if (application.getCoverLetter() != null) {
			apply.setCoverLetter(application.getCoverLetter());
		}
		if (application.getNumberCard() != null) {
			apply.setNumberCard(application.getNumberCard());
		}
		if (application.getNumberPhone() != null) {
			apply.setNumberPhone(application.getNumberPhone());
		}
		result = applications.save(apply);
		return result;
	}

	@Override
	public List<Application> allApplication() {

		return applications.findAll();
	}

	@Override
	public ApplicationDTO getApplication(Long id) {
		User paul = users.findById(id).get();
		ApplicationDTO result = null;
		if (paul == null) {
			return result;
		} else {
		Application apply = applications.findById(paul.getApplication().getId()).get();
		if (apply == null) {
			return result;
		} else {
		ApplicationDTO app = new ApplicationDTO();
		app.setAddress(apply.getAddress());
		app.setCity(apply.getCity());
		app.setCoverLetter(apply.getCoverLetter());
		app.setNumberCard(apply.getNumberCard());
		app.setNumberPhone(apply.getNumberPhone());
		app.setSectorLabel(apply.getActivitySector().getLabel());
		result = app;
		return result;
		}
		}
	}

	@Override
	public void removeApplication(Long id){
			
			User user = users.findById(id).get();
			Long appid = user.getApplication().getId();

			Application apply = applications.findById(appid).get();
			applications.delete(apply);
	}

}
