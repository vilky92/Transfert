package cjSecurity.controller.application;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cjSecurity.dto.ApplicationDTO;
import cjSecurity.dto.UserApplicationDTO;
import cjSecurity.model.application.Application;
import cjSecurity.service.application.IApplicationService;

@CrossOrigin(value = "*")
@RestController
@RequestMapping("/apli")
@PreAuthorize("hasRole('ROLE_admin') or hasRole('ROLE_user')")
public class ApplicationController {
	
	@Autowired
	IApplicationService applications;
	
	@PostMapping("/post")
	public ResponseEntity<?> createApplication(@RequestBody UserApplicationDTO applicationDTO) {
		
		return new ResponseEntity<Application>(applications.createApplication(applicationDTO),HttpStatus.OK);
		}
	
	
	
	@GetMapping("/get/{id}")
	public ResponseEntity<?> getOne(@PathVariable long id) {
		ApplicationDTO apply = null;
			apply = applications.getApplication(id);
			if (apply == null) {
				return new ResponseEntity<String>("vous n'avez pas encore postulé",HttpStatus.NOT_FOUND);
			}
		
		return new ResponseEntity<ApplicationDTO>((apply), HttpStatus.OK);
	}
	
	@GetMapping("/get/all")
	public ResponseEntity<?> getAll() {
		List <Application> list = new ArrayList<Application>();
		list = applications.allApplication();
		
		return new ResponseEntity<List<Application>>((list), HttpStatus.OK);
	}
	
	@PutMapping("/put")
	public ResponseEntity<?> putApplication(@RequestBody UserApplicationDTO application) {
		Application apply = null;
		apply = applications.updateApplication(application);
		
		return new ResponseEntity<Application>((apply), HttpStatus.OK);
	}
	
	//a réparer
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> deleteApplication(@PathVariable long id) {


		applications.removeApplication(id);


		return new ResponseEntity<Application>(HttpStatus.OK);
	}

}
