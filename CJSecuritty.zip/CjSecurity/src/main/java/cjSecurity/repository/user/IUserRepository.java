package cjSecurity.repository.user;

import org.springframework.data.jpa.repository.JpaRepository;

import cjSecurity.model.user.User;

public interface IUserRepository extends JpaRepository<User, Long> {


	User findByLogin(String login);

	boolean existsByLogin(String login);


}
