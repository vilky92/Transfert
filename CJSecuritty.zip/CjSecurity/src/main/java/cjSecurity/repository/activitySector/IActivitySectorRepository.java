package cjSecurity.repository.activitySector;

import org.springframework.data.jpa.repository.JpaRepository;

import cjSecurity.model.activitySector.ActivitySector;

public interface IActivitySectorRepository extends JpaRepository<ActivitySector, Long> {

	ActivitySector findByLabel(String sectorLabel);

}
